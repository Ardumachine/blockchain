# Preloaded Dashboards for Forest

## Dashboards

- `forest`: The forest dashboard keeps track of process, syncing, and execution metrics

## Updating

To update any dashboard, make changes to the dashboard in the Grafana web application, export the dashboard, and replace the dashboard JSON definition in this directory.
