// Copyright 2020 ChainSafe Systems
// SPDX-License-Identifier: Apache-2.0, MIT

/// Deal identifier used in market and miner actors
pub type DealID = u64;
