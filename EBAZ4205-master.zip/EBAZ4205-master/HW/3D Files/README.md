# EBAZ4205 3D Files

## EBAZ4205_Stand.stl

Uses four 5mm M3 Screws.
![Unmounted Stand](../../image/08-STAND.jpg)
![Mounted Stand](../../image/09-STAND.jpg)
