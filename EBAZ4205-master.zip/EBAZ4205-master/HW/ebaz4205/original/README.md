Sourced from

https://github.com/Elrori/EBAZ4205

The design seems to have been made in Protel DXP and needs to be imported in Altium.