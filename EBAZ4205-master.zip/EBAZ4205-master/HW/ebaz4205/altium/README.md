Altium import + fixes for proper polygon fill.

See [../README.md](../README.md) for details.